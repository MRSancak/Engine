#include "Editor.h"
#include <windows.h>
#include <string>

namespace Donder
{
    int Editor::Show(const std::wstring& projectPath)
    {
        std::wstring message =
            L"Proje açıldı!\\n\\n" +
            projectPath +
            L"\\n\\nDonder Editor temel sürümü çalışıyor.\\n"
            L"Sonraki aşamada 3D viewport, Scene/Hierarchy/Inspector ve C# runtime eklenecek.";

        MessageBoxW(nullptr, message.c_str(), L"Donder Engine", MB_OK | MB_ICONINFORMATION);
        return 0;
    }
}
