#pragma once
#include <string>

namespace Donder
{
    class Editor
    {
    public:
        static int Show(const std::wstring& projectPath);
    };
}
