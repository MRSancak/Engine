#include "Engine.h"
#include <iostream>

namespace Donder
{
    bool Engine::Start(const std::wstring& projectPath)
    {
        projectPath_ = projectPath;
        running_ = true;
        return true;
    }

    void Engine::Run()
    {
        std::wcout << L"Donder Engine started: " << projectPath_ << L"\n";
        std::wcout << L"Editor/3D renderer/C# runtime will be attached in the next modules.\n";
    }

    void Engine::Shutdown()
    {
        running_ = false;
    }
}
