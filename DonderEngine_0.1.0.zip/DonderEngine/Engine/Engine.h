#pragma once
#include <string>

namespace Donder
{
    class Engine
    {
    public:
        bool Start(const std::wstring& projectPath);
        void Run();
        void Shutdown();

    private:
        std::wstring projectPath_;
        bool running_ = false;
    };
}
