#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "../Editor/Editor.h"

namespace fs = std::filesystem;

static std::wstring GetText(HWND h)
{
    int len = GetWindowTextLengthW(h);
    std::wstring s(len, L'\0');
    GetWindowTextW(h, s.data(), len + 1);
    return s;
}

static bool ValidProjectName(const std::wstring& name)
{
    if (name.empty()) return false;
    const std::wstring bad = L"<>:\"/\\|?*";
    return name.find_first_of(bad) == std::wstring::npos;
}

static void WriteProjectFiles(const fs::path& project)
{
    fs::create_directories(project / "Assets");
    fs::create_directories(project / "Scenes");
    fs::create_directories(project / "Scripts");
    fs::create_directories(project / "Packages");
    fs::create_directories(project / "Settings");

    std::ofstream cfg(project / "project.donder", std::ios::binary);
    cfg << "{\n"
           "  \"engine\": \"DonderEngine\",\n"
           "  \"version\": \"0.1.0\",\n"
           "  \"name\": \"" << project.filename().string() << "\",\n"
           "  \"startupScene\": \"Scenes/Main.scene\",\n"
           "  \"scriptLanguage\": \"C#\"\n"
           "}\n";

    std::ofstream scene(project / "Scenes" / "Main.scene", std::ios::binary);
    scene << "{\n  \"scene\": \"Main\",\n  \"entities\": []\n}\n";

    std::ofstream cs(project / "Scripts" / "Game.cs", std::ios::binary);
    cs << "using Donder;\n\n"
          "public class Game : MonoBehaviour\n"
          "{\n"
          "    public void Start() { }\n"
          "    public void Update() { }\n"
          "}\n";
}

static fs::path ChooseFolder(HWND owner)
{
    BROWSEINFOW bi{};
    bi.hwndOwner = owner;
    bi.lpszTitle = L"Projelerin bulunacağı klasörü seç";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;

    PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return {};

    wchar_t path[MAX_PATH]{};
    SHGetPathFromIDListW(pidl, path);
    CoTaskMemFree(pidl);
    return fs::path(path);
}

class LauncherWindow
{
public:
    HWND hwnd{};
    HWND nameEdit{};
    HWND pathEdit{};
    HWND projectsList{};

    static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l)
    {
        LauncherWindow* self = reinterpret_cast<LauncherWindow*>(GetWindowLongPtrW(h, GWLP_USERDATA));

        if (m == WM_NCCREATE)
        {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(l);
            self = reinterpret_cast<LauncherWindow*>(cs->lpCreateParams);
            SetWindowLongPtrW(h, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
            self->hwnd = h;
        }

        if (self) return self->Handle(m, w, l);
        return DefWindowProcW(h, m, w, l);
    }

    LRESULT Handle(UINT m, WPARAM w, LPARAM l)
    {
        if (m == WM_CREATE)
        {
            HFONT font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

            CreateWindowW(L"STATIC", L"DONDER ENGINE",
                WS_CHILD | WS_VISIBLE, 30, 25, 500, 45, hwnd, nullptr, nullptr, nullptr);

            CreateWindowW(L"STATIC", L"3D Oyun Motoru • C++ + C#",
                WS_CHILD | WS_VISIBLE, 32, 68, 500, 25, hwnd, nullptr, nullptr, nullptr);

            CreateWindowW(L"BUTTON", L"PROJE OLUŞTUR",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                30, 110, 210, 42, hwnd, (HMENU)1001, nullptr, nullptr);

            CreateWindowW(L"STATIC", L"Proje Adı",
                WS_CHILD | WS_VISIBLE, 30, 175, 120, 25, hwnd, nullptr, nullptr, nullptr);

            nameEdit = CreateWindowW(L"EDIT", L"YeniOyun",
                WS_CHILD | WS_VISIBLE | WS_BORDER,
                30, 200, 300, 28, hwnd, nullptr, nullptr, nullptr);

            CreateWindowW(L"STATIC", L"Konum",
                WS_CHILD | WS_VISIBLE, 30, 245, 120, 25, hwnd, nullptr, nullptr, nullptr);

            pathEdit = CreateWindowW(L"EDIT", L"",
                WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
                30, 270, 400, 28, hwnd, nullptr, nullptr, nullptr);

            CreateWindowW(L"BUTTON", L"Konum Seç",
                WS_CHILD | WS_VISIBLE,
                440, 270, 110, 28, hwnd, (HMENU)1002, nullptr, nullptr);

            CreateWindowW(L"STATIC", L"Diğer Projeler",
                WS_CHILD | WS_VISIBLE, 30, 325, 200, 30, hwnd, nullptr, nullptr, nullptr);

            projectsList = CreateWindowW(L"LISTBOX", L"",
                WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY,
                30, 360, 520, 180, hwnd, (HMENU)1003, nullptr, nullptr);

            RefreshProjects();

            SendMessageW(nameEdit, WM_SETFONT, (WPARAM)font, TRUE);
            return 0;
        }

        if (m == WM_COMMAND)
        {
            const int id = LOWORD(w);

            if (id == 1002)
            {
                fs::path p = ChooseFolder(hwnd);
                if (!p.empty())
                    SetWindowTextW(pathEdit, p.c_str());
            }
            else if (id == 1001)
            {
                CreateProject();
            }
            else if (id == 1003 && HIWORD(w) == LBN_DBLCLK)
            {
                int index = (int)SendMessageW(projectsList, LB_GETCURSEL, 0, 0);
                if (index >= 0) OpenProject(index);
            }
        }

        if (m == WM_DESTROY)
        {
            PostQuitMessage(0);
            return 0;
        }

        return DefWindowProcW(hwnd, m, w, l);
    }

    void RefreshProjects()
    {
        SendMessageW(projectsList, LB_RESETCONTENT, 0, 0);
        fs::path root = fs::current_path() / "Projects";
        if (!fs::exists(root)) fs::create_directories(root);

        for (auto& e : fs::directory_iterator(root))
        {
            if (e.is_directory() && fs::exists(e.path() / "project.donder"))
            {
                std::wstring label = e.path().filename().wstring();
                SendMessageW(projectsList, LB_ADDSTRING, 0, (LPARAM)label.c_str());
            }
        }
    }

    void CreateProject()
    {
        std::wstring name = GetText(nameEdit);
        std::wstring parent = GetText(pathEdit);

        if (!ValidProjectName(name))
        {
            MessageBoxW(hwnd, L"Geçerli bir proje adı gir.", L"Hata", MB_OK | MB_ICONERROR);
            return;
        }

        if (parent.empty())
        {
            MessageBoxW(hwnd, L"Önce proje konumunu seç.", L"Hata", MB_OK | MB_ICONERROR);
            return;
        }

        fs::path project = fs::path(parent) / name;

        if (fs::exists(project))
        {
            MessageBoxW(hwnd, L"Bu klasörde aynı isimde bir proje zaten var.", L"Hata", MB_OK | MB_ICONERROR);
            return;
        }

        try
        {
            WriteProjectFiles(project);
            MessageBoxW(hwnd, L"Proje oluşturuldu. Motor açılıyor.", L"Donder Engine", MB_OK);
            Donder::Editor::Show(project.wstring());
            RefreshProjects();
        }
        catch (const std::exception& ex)
        {
            MessageBoxW(hwnd, L"Proje oluşturulurken hata oluştu.", L"Hata", MB_OK | MB_ICONERROR);
        }
    }

    void OpenProject(int index)
    {
        wchar_t buffer[512]{};
        SendMessageW(projectsList, LB_GETTEXT, index, (LPARAM)buffer);
        fs::path p = fs::current_path() / "Projects" / buffer;
        Donder::Editor::Show(p.wstring());
    }
};

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow)
{
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    const wchar_t CLASS_NAME[] = L"DonderLauncher";

    WNDCLASSW wc{};
    wc.lpfnWndProc = LauncherWindow::WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);

    LauncherWindow app;

    HWND hwnd = CreateWindowExW(
        0, CLASS_NAME, L"Donder Engine - Project Manager",
        WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME,
        CW_USEDEFAULT, CW_USEDEFAULT, 620, 610,
        nullptr, nullptr, hInstance, &app);

    if (!hwnd) return 1;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return 0;
}
