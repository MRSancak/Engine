# Donder Engine

Kendi 3D oyun motoru projesi.

## Hedef mimari

- C++: motor çekirdeği, render, ECS, fizik, asset sistemi, editor
- C#: oyun/script tarafı
- Project Manager: proje oluşturma ve açma
- Scene/Hierarchy/Inspector
- 3D Viewport
- Asset Browser
- C# hot reload / script compilation
- Windows başlangıç hedefi

## Şu anki sürüm

0.1.0 - Project Manager temel sürümü.

Launcher:
- Proje adı alır
- Kayıt konumu seçtirir
- Proje klasörünü oluşturur
- Assets, Scenes, Scripts, Packages ve Settings klasörlerini oluşturur
- project.donder oluşturur
- Main.scene oluşturur
- Game.cs oluşturur
- Oluşturulan projeleri "Diğer Projeler" listesinde gösterir
- Projeye çift tıklayınca editor temel penceresini açar

## Derleme

Visual Studio 2022 + C++ Desktop Development veya CMake kullanabilirsin.

```powershell
cmake -S . -B build
cmake --build build --config Release
```

Çıktı:
`build/bin/Release/DonderEngine.exe`

## Sonraki büyük modüller

1. OpenGL/Vulkan/DirectX render backend
2. Gerçek 3D viewport
3. Entity Component System
4. Scene serialization
5. Asset importer
6. C#/.NET embedding
7. MonoBehaviour benzeri component sistemi
8. Play/Stop
9. Inspector
10. Prefab sistemi
